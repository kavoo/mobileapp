create database skysalon; 

create table appointments (

    fname varchar(45),
    lname varchar(45),
    email varchar(45),
    phone varchar(10),
    comment varchar(255)
    createdon datetime,

);